<template>
  <div id="app">
    <vue-particles
      class="particles"
      color="#dedede"
      :particleOpacity="0.7"
      :particlesNumber="80"
      shapeType="circle"
      :particleSize="4"
      linesColor="#dedede"
      :linesWidth="1"
      :lineLinked="true"
      :lineOpacity="0.4"
      :linesDistance="150"
      :moveSpeed="3"
      :hoverEffect="true"
      hoverMode="grab"
      :clickEffect="true"
      clickMode="push"
    >
    </vue-particles>
    <div class="content">
      <img src="~@/assets/title.gif" alt="" />
      <div class="content-body">
        <p>
          在人类诞生之前，月亮只是距离地球38万千米的卫星，伴随着斗转星移，日复一日绕着轨道划出固定痕迹。当地球上有了人类，他们抬头仰望月亮，月亮开始有了浪漫的魔力。这颗星球成为漫游在宇宙里的情感寄宿者，收容来自地球的情绪、记忆和愿望。它牵引着地球上的潮汐，唤醒藏在人们心中的海啸。
        </p>
        <p>
          人们开始幻想有一日可以触摸到月亮，就像是难以压抑“在夜晚中跳舞的心”一样。
        </p>
        <p>
          德国流亡者威廉·赫歇尔爵士试图用望远镜去描摹月球上幻想中的森林，《月亮的距离》中人们尝试用梯子抵达月亮，喝醉酒的李白不忘在水边打捞月亮......直到有一天，阿姆斯特朗从月球上回来，他带着失望的心告诉人们月亮的真相：月亮只是一个荒无人烟的小星球。但是这依然挡不住人们对于月亮的迷恋。有一群人，他们从天上偷下来月亮，做成艺术装置放在了人间。因为那是月亮哎，是太阳出来之前，全世界唯一真实的梦境。
        </p>
        <p></p>
      </div>
    </div>
    <div class="footer">豫ICP备19040084号</div>
  </div>
</template>

<style lang="scss">
* {
  padding: 0;
  margin: 0;
}
html,
body {
  height: 100%;
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  width: 100%;
  height: 100%;
  position: relative;
  .particles {
    position: absolute;
    width: 100%;
    height: 100%;
  }
  .content {
    text-align: center;
    background-color: transparent;
    height: calc(100% - 100px);
  }
  .content-body {
    text-align: left;
    text-indent: 28px;
    padding: 0 20%;
    line-height: 40px;
  }
  .footer {
    text-align: center;
    line-height: 80px;
  }
}
</style>
